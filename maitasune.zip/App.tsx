
import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import LoginScreen from './screens/LoginScreen';
import RegistrationScreen from './screens/RegistrationScreen';
import MainLayout from './components/MainLayout';
import { api } from './services/database';
import type { User } from './types';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [authScreen, setAuthScreen] = useState<'login' | 'register'>('login');

  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const handleLogin = async (email: string, pass: string) => {
    const user = await api.authenticateUser(email, pass);
    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      setCurrentUser(user);
      return true;
    }
    return false;
  };
  
  const handleRegister = async (userData: Omit<User, 'id'>) => {
    const newUser = await api.addUser(userData);
    if (newUser) {
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      setCurrentUser(newUser);
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setCurrentUser(null);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-xl font-semibold text-blue-600">Loading Maitasune...</div>
      </div>
    );
  }

  return (
    <>
      {currentUser ? (
        <AppProvider>
            <MainLayout onLogout={handleLogout} />
        </AppProvider>
      ) : (
        authScreen === 'login' ? (
          <LoginScreen onLogin={handleLogin} onNavigateToRegister={() => setAuthScreen('register')} />
        ) : (
          <RegistrationScreen onRegister={handleRegister} onNavigateToLogin={() => setAuthScreen('login')} />
        )
      )}
    </>
  );
};

export default App;