

import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import Modal from './Modal';

interface AddActivityModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
}

const AddActivityModal: React.FC<AddActivityModalProps> = ({ isOpen, onClose, patientId }) => {
    const { addActivity } = useAppContext();
    const [name, setName] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [time, setTime] = useState('');
    const [reminderOffset, setReminderOffset] = useState<number>(0);
    const [errors, setErrors] = useState<{ name?: string; date?:string; time?: string }>({});

    const resetForm = () => {
        setName('');
        setDate(new Date().toISOString().split('T')[0]);
        setTime('');
        setReminderOffset(0);
        setErrors({});
    };

    const handleClose = () => {
        resetForm();
        onClose();
    };

    const validate = () => {
        const newErrors: { name?: string; date?: string; time?: string } = {};
        if (!name.trim()) newErrors.name = 'El nombre es obligatorio.';
        if (!date) newErrors.date = 'La fecha es obligatoria.';
        if (!time) {
            newErrors.time = 'La hora es obligatoria.';
        } else if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time)) {
            newErrors.time = 'Por favor, introduce un formato de hora válido (HH:MM).';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!validate()) return;

        await addActivity({
            patientId,
            name,
            date,
            time,
            completed: false,
            reminderOffset: reminderOffset > 0 ? reminderOffset : undefined,
        });

        handleClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={handleClose} title="Añadir Nueva Actividad">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="act-name" className="block text-sm font-medium text-gray-700">Nombre de la Actividad</label>
                    <input 
                        type="text" 
                        id="act-name"
                        value={name}
                        placeholder="Ej: Paseo matutino, Fisioterapia"
                        onChange={e => setName(e.target.value)}
                        className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
                        required
                    />
                    {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="act-date" className="block text-sm font-medium text-gray-700">Fecha</label>
                        <input 
                            type="date" 
                            id="act-date"
                            value={date}
                            onChange={e => setDate(e.target.value)}
                            className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${errors.date ? 'border-red-500' : 'border-gray-300'}`}
                            required
                        />
                        {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date}</p>}
                    </div>
                    <div>
                        <label htmlFor="act-time" className="block text-sm font-medium text-gray-700">Hora</label>
                        <input 
                            type="time" 
                            id="act-time"
                            value={time}
                            onChange={e => setTime(e.target.value)}
                            className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${errors.time ? 'border-red-500' : 'border-gray-300'}`}
                            required
                        />
                        {errors.time && <p className="text-red-500 text-xs mt-1">{errors.time}</p>}
                    </div>
                </div>
                <div>
                    <label htmlFor="act-reminder" className="block text-sm font-medium text-gray-700">Recordatorio</label>
                     <select 
                        id="act-reminder"
                        value={reminderOffset}
                        onChange={(e) => setReminderOffset(Number(e.target.value))}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    >
                        <option value={0}>Sin recordatorio</option>
                        <option value={5}>5 minutos antes</option>
                        <option value={15}>15 minutos antes</option>
                        <option value={30}>30 minutos antes</option>
                        <option value={60}>1 hora antes</option>
                    </select>
                </div>
                <div className="flex justify-end pt-4">
                    <button 
                        type="submit"
                        className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        Guardar Actividad
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default AddActivityModal;