
import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import Modal from './Modal';

interface AddPatientModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const AddPatientModal: React.FC<AddPatientModalProps> = ({ isOpen, onClose }) => {
    const { addPatient } = useAppContext();
    const [name, setName] = useState('');
    const [age, setAge] = useState('');
    const [condition, setCondition] = useState('');
    const [notes, setNotes] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!name || !age || !condition) return;

        await addPatient({
            name,
            age: parseInt(age, 10),
            condition,
            notes,
            avatarUrl: `https://picsum.photos/seed/${name.toLowerCase().replace(/\s/g, '')}/200`
        });

        // Reset form and close modal
        setName('');
        setAge('');
        setCondition('');
        setNotes('');
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Añadir Nueva Persona">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="patient-name" className="block text-sm font-medium text-gray-700">Nombre Completo</label>
                    <input 
                        type="text" 
                        id="patient-name"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="patient-age" className="block text-sm font-medium text-gray-700">Edad</label>
                    <input 
                        type="number" 
                        id="patient-age"
                        value={age}
                        onChange={e => setAge(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="patient-condition" className="block text-sm font-medium text-gray-700">Condición Principal</label>
                    <input
                        id="patient-condition"
                        value={condition}
                        onChange={e => setCondition(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="patient-notes" className="block text-sm font-medium text-gray-700">Notas Adicionales (Base del Paciente)</label>
                    <textarea 
                        id="patient-notes"
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                        rows={3}
                        placeholder="Alergias, preferencias, contactos..."
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>
                <div className="flex justify-end pt-4">
                    <button 
                        type="submit"
                        className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        Guardar Persona
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default AddPatientModal;