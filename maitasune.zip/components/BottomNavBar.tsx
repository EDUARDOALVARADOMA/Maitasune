import React from 'react';
import { GridIcon, PillIcon, MicrophoneIcon, ActivityIcon, ChartBarIcon } from './Icons';

type Screen = 'dashboard' | 'medication' | 'activities' | 'chat' | 'reports' | 'settings';

interface BottomNavBarProps {
  activeScreen: Screen;
  setActiveScreen: (screen: Screen) => void;
}

const NavItem: React.FC<{ Icon: React.FC<React.SVGProps<SVGSVGElement>>, label: string, isActive: boolean, onClick: () => void }> = ({ Icon, label, isActive, onClick }) => (
    <button onClick={onClick} className={`flex flex-col items-center justify-center w-full pt-2 pb-1 transition-colors duration-200 ${isActive ? 'text-indigo-600' : 'text-gray-500 hover:text-indigo-500'}`}>
        <Icon className="w-6 h-6" />
        <span className="text-xs font-medium mt-1">{label}</span>
    </button>
);

const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeScreen, setActiveScreen }) => {
    const navItems = [
        { id: 'dashboard', label: 'Hoy', icon: GridIcon },
        { id: 'medication', label: 'Medicación', icon: PillIcon },
        { id: 'activities', label: 'Actividades', icon: ActivityIcon },
        { id: 'reports', label: 'Seguimiento', icon: ChartBarIcon },
    ];
    
    const leftItems = navItems.slice(0, 2);
    const rightItems = navItems.slice(2);

    return (
        <footer className="bg-white rounded-b-[48px] border-t border-gray-200 shadow-[0_-5px_15px_-5px_rgba(0,0,0,0.1)]">
            <div className="flex justify-around items-center h-20 px-2">
                {leftItems.map(item => (
                    <NavItem 
                        key={item.id}
                        Icon={item.icon}
                        label={item.label}
                        isActive={activeScreen === item.id}
                        onClick={() => setActiveScreen(item.id as Screen)}
                    />
                ))}

                <div className="relative -top-6">
                    <button 
                        onClick={() => setActiveScreen('chat')} 
                        className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-lg transform hover:scale-110 transition-all duration-200 ${activeScreen === 'chat' ? 'bg-blue-700 scale-110' : 'bg-indigo-600'}`}
                        aria-label="Asistente IA"
                    >
                        <MicrophoneIcon className="w-8 h-8"/>
                    </button>
                </div>

                {rightItems.map(item => (
                     <NavItem 
                        key={item.id}
                        Icon={item.icon}
                        label={item.label}
                        isActive={activeScreen === item.id}
                        onClick={() => setActiveScreen(item.id as Screen)}
                    />
                ))}
            </div>
        </footer>
    );
};

export default BottomNavBar;