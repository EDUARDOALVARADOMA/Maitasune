import React, { useState, useMemo } from 'react';
import type { Activity } from '../types';
import { ChevronLeftIcon, ChevronRightIcon } from './Icons';

interface CalendarViewProps {
    activities: Activity[];
    onEditActivity: (activity: Activity) => void;
}

const CalendarView: React.FC<CalendarViewProps> = ({ activities, onEditActivity }) => {
    const [currentDate, setCurrentDate] = useState(new Date());

    const activitiesByDate = useMemo(() => {
        return activities.reduce((acc, activity) => {
            (acc[activity.date] = acc[activity.date] || []).push(activity);
            return acc;
        }, {} as Record<string, Activity[]>);
    }, [activities]);

    const handlePrevMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    };

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const calendarDays = [];
    // Padding for days before the 1st of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
        calendarDays.push(<div key={`pad-start-${i}`} className="border-r border-b border-gray-200"></div>);
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const dayActivities = activitiesByDate[dateStr] || [];
        const isToday = new Date().toISOString().split('T')[0] === dateStr;

        calendarDays.push(
            <div key={dateStr} className={`relative p-2 border-r border-b border-gray-200 min-h-[100px] flex flex-col ${isToday ? 'bg-blue-50' : ''}`}>
                <time dateTime={dateStr} className={`text-sm font-semibold ${isToday ? 'bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center' : 'text-gray-600'}`}>
                    {day}
                </time>
                <div className="flex-grow overflow-y-auto mt-1 space-y-1">
                    {dayActivities.map(activity => (
                        <div 
                            key={activity.id}
                            onClick={() => onEditActivity(activity)}
                            className="text-xs p-1 rounded-md cursor-pointer hover:bg-gray-200 transition-colors"
                        >
                            <span className={`inline-block w-2 h-2 rounded-full mr-1 ${activity.completed ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
                            <span className={activity.completed ? 'line-through text-gray-500' : 'text-gray-800'}>
                                {activity.name}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        );
    }
    
     // Padding for days after the last day of the month
    const totalCells = firstDayOfMonth + daysInMonth;
    const remainingCells = (7 - (totalCells % 7)) % 7;
    for (let i = 0; i < remainingCells; i++) {
        calendarDays.push(<div key={`pad-end-${i}`} className="border-r border-b border-gray-200"></div>);
    }

    const weekDays = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    return (
        <div className="bg-white p-4 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
                <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-gray-100">
                    <ChevronLeftIcon />
                </button>
                <h2 className="text-lg font-semibold text-gray-800">
                    {currentDate.toLocaleString('es-ES', { month: 'long', year: 'numeric' })}
                </h2>
                <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-gray-100">
                    <ChevronRightIcon />
                </button>
            </div>
            <div className="grid grid-cols-7 border-t border-l border-gray-200">
                {weekDays.map(day => (
                    <div key={day} className="text-center text-xs font-bold text-gray-500 p-2 border-r border-b border-gray-200 bg-gray-50">
                        {day}
                    </div>
                ))}
                {calendarDays}
            </div>
        </div>
    );
};

export default CalendarView;
