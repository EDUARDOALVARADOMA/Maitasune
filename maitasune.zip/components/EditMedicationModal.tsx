import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import Modal from './Modal';
import { Medication } from '../types';

interface EditMedicationModalProps {
    isOpen: boolean;
    onClose: () => void;
    medication: Medication | null;
}

const EditMedicationModal: React.FC<EditMedicationModalProps> = ({ isOpen, onClose, medication }) => {
    const { updateMedication } = useAppContext();
    const [name, setName] = useState('');
    const [dosage, setDosage] = useState('');
    const [time, setTime] = useState('');
    const [errors, setErrors] = useState<{ name?: string; dosage?: string; time?: string }>({});

    useEffect(() => {
        if (medication) {
            setName(medication.name);
            setDosage(medication.dosage);
            setTime(medication.time);
            setErrors({});
        }
    }, [medication, isOpen]);

    const handleClose = () => {
        setErrors({});
        onClose();
    };

    const validate = () => {
        const newErrors: { name?: string; dosage?: string; time?: string } = {};
        if (!name.trim()) newErrors.name = 'El nombre es obligatorio.';
        if (!dosage.trim()) newErrors.dosage = 'La dosis es obligatoria.';
        if (!time) {
            newErrors.time = 'La hora es obligatoria.';
        } else if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time)) {
            newErrors.time = 'Por favor, introduce un formato de hora válido (HH:MM).';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!validate() || !medication) return;

        await updateMedication(medication.id, {
            name,
            dosage,
            time,
        });

        handleClose();
    };

    if (!medication) return null;

    return (
        <Modal isOpen={isOpen} onClose={handleClose} title="Editar Medicamento">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="edit-med-name" className="block text-sm font-medium text-gray-700">Nombre del Medicamento</label>
                    <input 
                        type="text" 
                        id="edit-med-name"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
                        required
                    />
                     {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>
                 <div>
                    <label htmlFor="edit-med-dosage" className="block text-sm font-medium text-gray-700">Dosis</label>
                    <input 
                        type="text" 
                        id="edit-med-dosage"
                        value={dosage}
                        placeholder="Ej: 500mg, 1 comprimido"
                        onChange={e => setDosage(e.target.value)}
                        className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${errors.dosage ? 'border-red-500' : 'border-gray-300'}`}
                        required
                    />
                    {errors.dosage && <p className="text-red-500 text-xs mt-1">{errors.dosage}</p>}
                </div>
                 <div>
                    <label htmlFor="edit-med-time" className="block text-sm font-medium text-gray-700">Hora</label>
                    <input 
                        type="time" 
                        id="edit-med-time"
                        value={time}
                        onChange={e => setTime(e.target.value)}
                        className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 ${errors.time ? 'border-red-500' : 'border-gray-300'}`}
                        required
                    />
                    {errors.time && <p className="text-red-500 text-xs mt-1">{errors.time}</p>}
                </div>
                <div className="flex justify-end pt-4">
                    <button 
                        type="submit"
                        className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        Guardar Cambios
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default EditMedicationModal;