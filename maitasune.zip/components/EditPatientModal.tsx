
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import Modal from './Modal';
import { Patient } from '../types';

interface EditPatientModalProps {
    isOpen: boolean;
    onClose: () => void;
    patient: Patient | null;
}

const EditPatientModal: React.FC<EditPatientModalProps> = ({ isOpen, onClose, patient }) => {
    const { updatePatient } = useAppContext();
    const [name, setName] = useState('');
    const [age, setAge] = useState('');
    const [condition, setCondition] = useState('');
    const [notes, setNotes] = useState('');

    useEffect(() => {
        if (patient) {
            setName(patient.name);
            setAge(patient.age.toString());
            setCondition(patient.condition);
            setNotes(patient.notes || '');
        }
    }, [patient, isOpen]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!name || !age || !condition || !patient) return;

        await updatePatient(patient.id, {
            name,
            age: parseInt(age, 10),
            condition,
            notes,
        });
        
        onClose();
    };

    if (!patient) return null;

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Editar Persona Cuidada">
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="edit-patient-name" className="block text-sm font-medium text-gray-700">Nombre Completo</label>
                    <input 
                        type="text" 
                        id="edit-patient-name"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="edit-patient-age" className="block text-sm font-medium text-gray-700">Edad</label>
                    <input 
                        type="number" 
                        id="edit-patient-age"
                        value={age}
                        onChange={e => setAge(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="edit-patient-condition" className="block text-sm font-medium text-gray-700">Condición Principal</label>
                    <input
                        id="edit-patient-condition"
                        value={condition}
                        onChange={e => setCondition(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="edit-patient-notes" className="block text-sm font-medium text-gray-700">Notas Adicionales (Base del Paciente)</label>
                    <textarea 
                        id="edit-patient-notes"
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                        rows={3}
                        placeholder="Alergias, preferencias, contactos..."
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                </div>
                <div className="flex justify-end pt-4">
                    <button 
                        type="submit"
                        className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        Guardar Cambios
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default EditPatientModal;