import React from 'react';
import { useAppContext } from '../context/AppContext';
import { SettingsIcon } from './Icons';

type Screen = 'dashboard' | 'medication' | 'activities' | 'chat' | 'reports' | 'settings';

const screenTitles: { [key in Screen]: string } = {
    dashboard: 'Hoy',
    medication: 'Medicación',
    activities: 'Actividades',
    chat: 'Asistente IA',
    reports: 'Seguimiento',
    settings: 'Ajustes',
};

interface HeaderProps {
    activeScreen: Screen;
    setActiveScreen: (screen: Screen) => void;
}

const Header: React.FC<HeaderProps> = ({ activeScreen, setActiveScreen }) => {
    const { selectedPatient, currentUser } = useAppContext();
    return (
        <header className="sticky top-0 z-10 bg-[#76D7C4] p-4 rounded-t-[46px] flex flex-col gap-2">
            <div className="flex items-center justify-between">
                 <h1 className="text-3xl font-bold text-black">{screenTitles[activeScreen]}</h1>
                 <button onClick={() => setActiveScreen('settings')} className="p-2 rounded-full hover:bg-black/10 transition-colors" aria-label="Ajustes y Perfil">
                    <SettingsIcon className="w-6 h-6 text-black"/>
                 </button>
            </div>
            {(currentUser || selectedPatient) && (
              <div className="flex items-center justify-between text-sm bg-black/10 p-2 rounded-lg">
                  <div className="truncate">
                      <span className="font-semibold text-black/70">Cuidador/a:</span> <span className="font-medium text-black">{currentUser?.name || '...'}</span>
                  </div>
                  {selectedPatient ? (
                    <div className="flex items-center gap-2 truncate">
                        <span className="font-semibold text-black/70">Atendiendo a:</span> <span className="font-medium text-black">{selectedPatient.name}</span>
                        <img src={selectedPatient.avatarUrl} alt={selectedPatient.name} className="w-6 h-6 rounded-full object-cover border border-white/50"/>
                    </div>
                  ) : (
                    <div className="text-xs font-medium text-black/60">Ninguna persona seleccionada</div>
                  )}
              </div>
            )}
        </header>
    );
};

export default Header;
