import React, { useState } from 'react';
import Header from './Header';
import BottomNavBar from './BottomNavBar';
import DashboardScreen from '../screens/DashboardScreen';
import MedicationScreen from '../screens/MedicationScreen';
import ActivitiesScreen from '../screens/ActivitiesScreen';
import ChatScreen from '../screens/ChatScreen';
import ReportsScreen from '../screens/ReportsScreen';
import SettingsScreen from '../screens/SettingsScreen';

type Screen = 'dashboard' | 'medication' | 'activities' | 'chat' | 'reports' | 'settings';

interface MainLayoutProps {
  onLogout: () => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ onLogout }) => {
  const [activeScreen, setActiveScreen] = useState<Screen>('dashboard');

  const renderScreen = () => {
    switch (activeScreen) {
      case 'dashboard':
        return <DashboardScreen />;
      case 'medication':
        return <MedicationScreen />;
      case 'activities':
        return <ActivitiesScreen />;
      case 'chat':
        return <ChatScreen />;
      case 'reports':
        return <ReportsScreen />;
      case 'settings':
        return <SettingsScreen onLogout={onLogout} />;
      default:
        return <DashboardScreen />;
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-200 p-4">
        <div className="relative w-full max-w-[390px] h-[844px] bg-gray-100 rounded-[50px] shadow-2xl overflow-hidden border-4 border-black flex flex-col">
            <Header activeScreen={activeScreen} setActiveScreen={setActiveScreen} />
            <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-gray-50">
              {renderScreen()}
            </main>
            <BottomNavBar activeScreen={activeScreen} setActiveScreen={setActiveScreen} />
        </div>
    </div>
  );
};

export default MainLayout;