
import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { HomeIcon, PillIcon, ActivityIcon, MessageSquareIcon, LogOutIcon, UsersIcon, ChevronLeftIcon, ChevronRightIcon, MenuIcon, PlusIcon, ChartBarIcon, MaitasuneLogo, PencilIcon, BellIcon, BellOffIcon } from './Icons';
import AddPatientModal from './AddPatientModal';
import EditPatientModal from './EditPatientModal';


type Screen = 'dashboard' | 'medication' | 'activities' | 'chat' | 'reports';

interface SidebarProps {
  activeScreen: Screen;
  setActiveScreen: (screen: Screen) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeScreen, setActiveScreen, onLogout }) => {
  const { patients, selectedPatient, setSelectedPatient, settings, updateSettings } = useAppContext();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
  const [isEditPatientModalOpen, setIsEditPatientModalOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <HomeIcon /> },
    { id: 'medication', label: 'Medicación', icon: <PillIcon /> },
    { id: 'activities', label: 'Actividades', icon: <ActivityIcon /> },
    { id: 'reports', label: 'Informes', icon: <ChartBarIcon /> },
    { id: 'chat', label: 'Asistente IA', icon: <MessageSquareIcon /> },
  ];
  
  const handleNotificationToggle = async () => {
    const isEnabled = settings?.notificationsEnabled;

    if (!isEnabled) { // If currently disabled, we want to enable them
        if (!('Notification' in window)) {
            alert('Este navegador no soporta notificaciones de escritorio.');
            return;
        }

        if (Notification.permission === 'default') {
            const permission = await Notification.requestPermission();
            if (permission === 'granted') {
                await updateSettings({ notificationsEnabled: true });
                new Notification('¡Notificaciones Activadas!', {
                    body: 'Maitasune ahora te enviará recordatorios de medicación.',
                    icon: '/logo.png',
                });
            }
        } else if (Notification.permission === 'granted') {
            await updateSettings({ notificationsEnabled: true });
        } else {
            alert('Las notificaciones están bloqueadas. Por favor, habilítalas en la configuración de tu navegador para usar esta función.');
        }
    } else { // If currently enabled, disable them
        await updateSettings({ notificationsEnabled: false });
    }
  };

  const sidebarContent = (
    <div className={`flex flex-col h-full bg-white shadow-lg transition-width duration-300 ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <div className={`flex items-center p-4 border-b border-gray-200 ${isCollapsed ? 'justify-center' : 'justify-between'}`}>
        {!isCollapsed && 
            <div className='flex items-center gap-2'>
                <MaitasuneLogo className="w-8 h-8" />
                <span className="text-xl font-bold text-blue-700">Maitasune</span>
            </div>
        }
         <button onClick={() => setIsCollapsed(!isCollapsed)} className="hidden lg:block p-1 rounded-full hover:bg-gray-200 text-gray-600">
            {isCollapsed ? <ChevronRightIcon /> : <ChevronLeftIcon />}
        </button>
      </div>

      <div className="p-4 border-b border-gray-200">
        <div className={`flex items-center justify-between mb-1 ${isCollapsed ? 'justify-center' : ''}`}>
             {!isCollapsed && <label htmlFor="patient-select" className="block text-sm font-medium text-gray-700">Persona Cuidada</label>}
             {isCollapsed && <UsersIcon className="text-gray-600" />}
             {!isCollapsed && (
                 <div className="flex items-center space-x-1">
                    {selectedPatient && (
                        <button onClick={() => setIsEditPatientModalOpen(true)} className="p-1 rounded-full hover:bg-blue-100 text-blue-600" aria-label="Editar persona">
                            <PencilIcon className="w-4 h-4" />
                        </button>
                    )}
                    <button onClick={() => setIsAddPatientModalOpen(true)} className="p-1 rounded-full hover:bg-blue-100 text-blue-600" aria-label="Añadir persona">
                        <PlusIcon />
                    </button>
                 </div>
             )}
        </div>
        
        {!isCollapsed &&
        <select
            id="patient-select"
            value={selectedPatient?.id || ''}
            onChange={(e) => {
                const patient = patients.find(p => p.id === e.target.value);
                setSelectedPatient(patient || null);
            }}
            className="w-full mt-1 block pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
        >
            {patients.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
            ))}
        </select>
        }
      </div>

      <nav className="flex-grow px-2 py-4 space-y-2">
        {navItems.map(item => (
          <a
            key={item.id}
            href="#"
            onClick={(e) => {
              e.preventDefault();
              setActiveScreen(item.id as Screen);
              setIsMobileMenuOpen(false);
            }}
            className={`flex items-center p-3 rounded-lg transition-colors duration-200 ${
              activeScreen === item.id
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-600 hover:bg-blue-50 hover:text-blue-600'
            } ${isCollapsed ? 'justify-center' : ''}`}
          >
            {item.icon}
            {!isCollapsed && <span className="ml-4 font-medium">{item.label}</span>}
          </a>
        ))}
      </nav>

      <div className="p-2 border-t border-gray-200">
         <a
            href="#"
            onClick={(e) => {
                e.preventDefault();
                handleNotificationToggle();
            }}
            title={settings?.notificationsEnabled ? 'Desactivar recordatorios' : 'Activar recordatorios'}
            className={`flex items-center p-3 rounded-lg ${
                settings?.notificationsEnabled 
                    ? 'text-gray-600 hover:bg-blue-50 hover:text-blue-600' 
                    : 'text-gray-400 hover:bg-gray-100 hover:text-gray-600'
            } ${isCollapsed ? 'justify-center' : ''}`}
        >
            {settings?.notificationsEnabled ? <BellIcon /> : <BellOffIcon />}
            {!isCollapsed && <span className="ml-4 font-medium">Recordatorios</span>}
        </a>
        <a
          href="#"
          onClick={(e) => {
              e.preventDefault();
              onLogout();
          }}
          className={`flex items-center p-3 rounded-lg text-gray-600 hover:bg-red-50 hover:text-red-600 ${isCollapsed ? 'justify-center' : ''}`}
        >
          <LogOutIcon />
          {!isCollapsed && <span className="ml-4 font-medium">Cerrar Sesión</span>}
        </a>
      </div>
      <AddPatientModal isOpen={isAddPatientModalOpen} onClose={() => setIsAddPatientModalOpen(false)} />
      <EditPatientModal isOpen={isEditPatientModalOpen} onClose={() => setIsEditPatientModalOpen(false)} patient={selectedPatient} />
    </div>
  );

  return (
    <>
        {/* Mobile Sidebar */}
        <div className="lg:hidden">
            <button onClick={() => setIsMobileMenuOpen(true)} className="absolute top-4 left-4 z-20 p-2 bg-white rounded-full shadow-md">
                <MenuIcon />
            </button>
            <div className={`absolute inset-0 z-30 bg-black bg-opacity-50 transition-opacity ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsMobileMenuOpen(false)}></div>
            <div className={`absolute top-0 left-0 h-full z-40 transform transition-transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                 {React.cloneElement(sidebarContent, { isCollapsed: false })}
            </div>
        </div>
        
        {/* Desktop Sidebar */}
        <div className="hidden lg:block h-full">
            {sidebarContent}
        </div>
    </>
  );
};

export default Sidebar;