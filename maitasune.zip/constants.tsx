

import type { Patient, Medication, Activity, User, UserSettings } from './types';

export const INITIAL_USERS: User[] = [
  { id: 'user1', name: 'Alex Smith', email: 'alex.smith@example.com', password: 'password123', role: 'caregiver' },
];

export const INITIAL_USER_SETTINGS: UserSettings[] = [
  { userId: 'user1', theme: 'light', notificationsEnabled: true, speechRate: 1 },
];

export const INITIAL_PATIENTS: Patient[] = [
  {
    id: '1',
    userId: 'user1',
    name: 'Elena Garcia',
    avatarUrl: 'https://picsum.photos/seed/elena/200',
    age: 78,
    condition: 'Post-hip surgery recovery',
    notes: 'Needs help with mobility. Prefers meals at room temperature.'
  },
  {
    id: '2',
    userId: 'user1',
    name: 'Carlos Rodriguez',
    avatarUrl: 'https://picsum.photos/seed/carlos/200',
    age: 82,
    condition: 'Managing diabetes',
    notes: 'Monitor blood sugar before meals. Enjoys listening to classical music in the afternoon.'
  },
];

export const INITIAL_MEDICATIONS: Medication[] = [
  { id: 'm1', patientId: '1', name: 'Pain Reliever', dosage: '500mg', time: '08:00', taken: true },
  { id: 'm2', patientId: '1', name: 'Antibiotic', dosage: '250mg', time: '08:00', taken: true },
  { id: 'm3', patientId: '1', name: 'Pain Reliever', dosage: '500mg', time: '20:00', taken: false },
  { id: 'm4', patientId: '2', name: 'Metformin', dosage: '1000mg', time: '09:00', taken: true },
  { id: 'm5', patientId: '2', name: 'Insulin', dosage: '10 units', time: '21:00', taken: false },
];

const today = new Date();
const tomorrow = new Date(today);
tomorrow.setDate(today.getDate() + 1);
const yesterday = new Date(today);
yesterday.setDate(today.getDate() - 1);
const dayAfterTomorrow = new Date(today);
dayAfterTomorrow.setDate(today.getDate() + 2);

const formatDate = (date: Date): string => date.toISOString().split('T')[0];


export const INITIAL_ACTIVITIES: Activity[] = [
    { id: 'a1', patientId: '1', name: 'Morning Walk', date: formatDate(today), time: '10:00', completed: true, mood: 'happy' },
    { id: 'a2', patientId: '1', name: 'Physical Therapy', date: formatDate(today), time: '15:00', completed: false, reminderOffset: 15 },
    { id: 'a3', patientId: '2', name: 'Blood Sugar Check', date: formatDate(today), time: '09:00', completed: true, mood: 'neutral' },
    { id: 'a4', patientId: '2', name: 'Light Stretching', date: formatDate(tomorrow), time: '11:00', completed: false },
    { id: 'a5', patientId: '1', name: 'Read a book', date: formatDate(yesterday), time: '16:00', completed: true, mood: 'happy' },
    { id: 'a6', patientId: '2', name: 'Call family', date: formatDate(dayAfterTomorrow), time: '18:00', completed: false },
];