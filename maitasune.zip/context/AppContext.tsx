import React, { createContext, useContext, useState, ReactNode, useEffect, useCallback, useRef } from 'react';
import type { Patient, Medication, Activity, User, UserSettings, ChatMemory } from '../types';
import { api } from '../services/database';

interface AppContextType {
  currentUser: User | null;
  settings: UserSettings | null;
  patients: Patient[];
  medications: Medication[];
  activities: Activity[];
  addPatient: (patient: Omit<Patient, 'id' | 'userId'>) => Promise<void>;
  updatePatient: (patientId: string, updates: Partial<Patient>) => Promise<void>;
  deletePatient: (patientId: string) => Promise<void>;
  addMedication: (medication: Omit<Medication, 'id'>) => Promise<void>;
  addActivity: (activity: Omit<Activity, 'id'>) => Promise<void>;
  updateMedication: (medicationId: string, updates: Partial<Medication>) => Promise<void>;
  updateActivity: (activityId: string, updates: Partial<Activity>) => Promise<void>;
  updateSettings: (updates: Partial<UserSettings>) => Promise<void>;
  selectedPatient: Patient | null;
  setSelectedPatient: (patient: Patient | null) => void;
  isLoading: boolean;
  chatMemories: ChatMemory[];
  addChatMemory: (memory: Omit<ChatMemory, 'id'>) => Promise<void>;
  deleteChatMemory: (memoryId: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [chatMemories, setChatMemories] = useState<ChatMemory[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const notificationsSentToday = useRef(new Set<string>());

  // Effect to reset sent notifications at midnight
  useEffect(() => {
    const setMidnightReset = () => {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      const msUntilMidnight = tomorrow.getTime() - now.getTime();
      
      const timerId = setTimeout(() => {
        notificationsSentToday.current.clear();
        setMidnightReset(); // Reschedule for the next day
      }, msUntilMidnight);

      return () => clearTimeout(timerId);
    };
    
    const clearTimer = setMidnightReset();
    return clearTimer;
  }, []);

  // Effect to check for medication and activity reminders and send notifications
  useEffect(() => {
    if (!('Notification' in window)) {
        console.warn('This browser does not support desktop notification');
        return;
    }

    const intervalId = setInterval(() => {
      if (!settings?.notificationsEnabled || Notification.permission !== 'granted') {
        return;
      }

      const now = new Date();
      const todayStr = now.toISOString().split('T')[0]; // YYYY-MM-DD format
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      
      // Medication Reminders
      medications.forEach(med => {
        const patient = patients.find(p => p.id === med.patientId);
        // Check time, not taken, patient exists, and notification not already sent
        if (med.time === currentTime && !med.taken && patient && !notificationsSentToday.current.has(med.id)) {
          new Notification('Recordatorio de Medicación', {
            body: `Es hora de que ${patient.name} tome su ${med.name} (${med.dosage}).`,
            icon: '/logo.png',
            tag: med.id,
          });
          notificationsSentToday.current.add(med.id);
        }
      });
      
      // Activity Reminders
      activities.forEach(act => {
        // Only check activities for today that are not completed and have a reminder set
        if (act.date === todayStr && !act.completed && act.reminderOffset && act.reminderOffset > 0) {
            const [hours, minutes] = act.time.split(':').map(Number);
            const activityTime = new Date();
            activityTime.setHours(hours, minutes, 0, 0);

            const reminderTime = new Date(activityTime.getTime() - act.reminderOffset * 60000); // subtract offset in milliseconds

            const reminderTimeStr = `${reminderTime.getHours().toString().padStart(2, '0')}:${reminderTime.getMinutes().toString().padStart(2, '0')}`;
            const reminderId = `${act.id}-reminder`;

            const patient = patients.find(p => p.id === act.patientId);

            if (reminderTimeStr === currentTime && patient && !notificationsSentToday.current.has(reminderId)) {
              new Notification('Recordatorio de Actividad', {
                body: `La actividad "${act.name}" para ${patient.name} está programada para dentro de ${act.reminderOffset} minutos.`,
                icon: '/logo.png',
                tag: reminderId,
              });
              notificationsSentToday.current.add(reminderId);
            }
        }
      });

    }, 30000); // Check every 30 seconds

    return () => clearInterval(intervalId);
  }, [settings, medications, activities, patients]);

  const fetchData = useCallback(async (userId: string) => {
    setIsLoading(true);
    try {
      const [user, userSettings, userPatients, allMeds, allActs] = await Promise.all([
        api.getUser(userId),
        api.getSettings(userId),
        api.getPatients(userId),
        api.getMedications(),
        api.getActivities()
      ]);
      
      setCurrentUser(user || null);
      setSettings(userSettings || null);
      setPatients(userPatients);
      setMedications(allMeds);
      setActivities(allActs);
      
      if (userPatients.length > 0) {
        const allMemories = await Promise.all(userPatients.map(p => api.getChatMemories(p.id)));
        setChatMemories(allMemories.flat());

        // On initial load, select the first patient if none is selected
        if (!selectedPatient) {
          setSelectedPatient(userPatients[0]);
        }
      } else {
        setChatMemories([]);
        setSelectedPatient(null);
      }

    } catch (error) {
      console.error("Failed to fetch data:", error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedPatient]);
  
  // On mount, get logged-in user and fetch their data
  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
        const user: User = JSON.parse(storedUser);
        fetchData(user.id);
    } else {
        setIsLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run only once on mount

  const addPatient = async (patientData: Omit<Patient, 'id' | 'userId'>) => {
    if (!currentUser) return;
    const newPatient = await api.addPatient({ ...patientData, userId: currentUser.id });
    setPatients(prev => [...prev, newPatient]);
    if (patients.length === 0) {
        setSelectedPatient(newPatient);
    }
  };

  const updatePatient = async (patientId: string, updates: Partial<Patient>) => {
    const updatedPatient = await api.updatePatient(patientId, updates);
    if (updatedPatient) {
        setPatients(prev => prev.map(p => p.id === patientId ? updatedPatient : p));
        if (selectedPatient?.id === patientId) {
            setSelectedPatient(updatedPatient);
        }
    }
  };

  const deletePatient = async (patientId: string) => {
    const success = await api.deletePatient(patientId);
    if (success) {
        const remainingPatients = patients.filter(p => p.id !== patientId);
        setPatients(remainingPatients);
        setMedications(prev => prev.filter(m => m.patientId !== patientId));
        setActivities(prev => prev.filter(a => a.patientId !== patientId));
        setChatMemories(prev => prev.filter(m => m.patientId !== patientId));
        
        if (selectedPatient?.id === patientId) {
            setSelectedPatient(remainingPatients.length > 0 ? remainingPatients[0] : null);
        }
    }
  };

  const addMedication = async (medicationData: Omit<Medication, 'id'>) => {
    const newMedication = await api.addMedication(medicationData);
    setMedications(prev => [...prev, newMedication]);
  };
  
  const updateMedication = async (medicationId: string, updates: Partial<Medication>) => {
    const updatedMedication = await api.updateMedication(medicationId, updates);
    if (updatedMedication) {
      setMedications(prev => prev.map(m => m.id === medicationId ? updatedMedication : m));
    }
  };

  const addActivity = async (activityData: Omit<Activity, 'id'>) => {
    const newActivity = await api.addActivity(activityData);
    setActivities(prev => [...prev, newActivity]);
  };

  const updateActivity = async (activityId: string, updates: Partial<Activity>) => {
    const updatedActivity = await api.updateActivity(activityId, updates);
    if (updatedActivity) {
      setActivities(prev => prev.map(a => a.id === activityId ? updatedActivity : a));
    }
  };
  
  const updateSettings = async (updates: Partial<UserSettings>) => {
    if (!currentUser) return;
    const updatedSettings = await api.updateSettings(currentUser.id, updates);
    if (updatedSettings) {
        setSettings(updatedSettings);
    }
  };

  const addChatMemory = async (memoryData: Omit<ChatMemory, 'id'>) => {
    const newMemory = await api.addChatMemory(memoryData);
    // Avoid adding duplicates to state if api logic prevents it
    if (!chatMemories.some(m => m.id === newMemory.id)) {
        setChatMemories(prev => [...prev, newMemory]);
    }
  };

  const deleteChatMemory = async (memoryId: string) => {
    const success = await api.deleteChatMemory(memoryId);
    if (success) {
        setChatMemories(prev => prev.filter(m => m.id !== memoryId));
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        settings,
        patients,
        medications,
        activities,
        addPatient,
        updatePatient,
        deletePatient,
        addMedication,
        addActivity,
        updateMedication,
        updateActivity,
        updateSettings,
        selectedPatient,
        setSelectedPatient,
        isLoading,
        chatMemories,
        addChatMemory,
        deleteChatMemory
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};