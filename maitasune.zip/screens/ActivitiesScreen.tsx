

import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { PlusIcon, PencilIcon, BellIcon } from '../components/Icons';
import AddActivityModal from '../components/AddActivityModal';
import EditActivityModal from '../components/EditActivityModal';
import { Activity } from '../types';
import { playCompletionSound } from '../utils/soundUtils';
import CalendarView from '../components/CalendarView';

const MoodSelector: React.FC<{ activityId: string, currentMood?: string, onSelect: (activityId: string, mood: 'happy' | 'neutral' | 'sad') => void }> = ({ activityId, currentMood, onSelect }) => {
    const moods = [
        { name: 'happy', emoji: '😊' },
        { name: 'neutral', emoji: '😐' },
        { name: 'sad', emoji: '😔' },
    ];
    return (
        <div className="flex space-x-2">
            {moods.map(mood => (
                <button 
                    key={mood.name} 
                    onClick={() => onSelect(activityId, mood.name as 'happy' | 'neutral' | 'sad')}
                    className={`p-1.5 rounded-full text-xl transition-transform transform hover:scale-125 ${currentMood === mood.name ? 'bg-blue-200' : 'bg-gray-100'}`}
                >
                    {mood.emoji}
                </button>
            ))}
        </div>
    );
};

const ViewToggle: React.FC<{ view: 'list' | 'calendar'; setView: (view: 'list' | 'calendar') => void }> = ({ view, setView }) => (
    <div className="flex items-center bg-gray-200 rounded-lg p-1">
        <button
            onClick={() => setView('list')}
            className={`px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${view === 'list' ? 'bg-white text-blue-600 shadow' : 'text-gray-600'}`}
        >
            Lista
        </button>
        <button
            onClick={() => setView('calendar')}
            className={`px-4 py-1.5 text-sm font-semibold rounded-md transition-colors ${view === 'calendar' ? 'bg-white text-blue-600 shadow' : 'text-gray-600'}`}
        >
            Calendario
        </button>
    </div>
);

const ActivitiesScreen: React.FC = () => {
  const { selectedPatient, activities, updateActivity } = useAppContext();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  const [view, setView] = useState<'list' | 'calendar'>('list');

  const handleOpenEditModal = (act: Activity) => {
    setSelectedActivity(act);
    setIsEditModalOpen(true);
  };

  const handleToggleCompleted = (activityId: string, isCompleted: boolean) => {
    updateActivity(activityId, { completed: isCompleted });
    if (isCompleted) {
      playCompletionSound();
    }
  };

  if (!selectedPatient) {
    return (
      <div className="flex items-center justify-center h-full">
         <div className="text-center p-8 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-gray-700">Registro de Actividades</h2>
            <p className="mt-2 text-gray-500">Seleccione una persona en Ajustes para ver su plan de actividades.</p>
        </div>
      </div>
    );
  }

  const patientActivities = activities
    .filter(act => act.patientId === selectedPatient.id)
    .sort((a,b) => (a.date + a.time).localeCompare(b.date + b.time));

  const handleMoodSelect = (activityId: string, mood: 'happy' | 'neutral' | 'sad') => {
    updateActivity(activityId, { mood });
  };
  
  const formatDateForDisplay = (dateString: string) => {
      const date = new Date(dateString + 'T00:00:00'); // Avoid timezone issues
      return date.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
         <ViewToggle view={view} setView={setView} />
         <button 
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition-colors"
        >
            <PlusIcon />
            Añadir
        </button>
      </div>
      
      {view === 'list' ? (
        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hora</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actividad</th>
                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ánimo</th>
                    <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Editar</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {patientActivities.map(act => (
                    <tr key={act.id} className={act.completed ? 'bg-green-50' : ''}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{formatDateForDisplay(act.date)}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-500">
                        <div className="flex items-center gap-2">
                            <span>{act.time}</span>
                            {act.reminderOffset && act.reminderOffset > 0 && (
                                <span title={`Recordatorio ${act.reminderOffset} min antes`}>
                                    <BellIcon className="w-4 h-4 text-blue-500" />
                                </span>
                            )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{act.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                        <input
                          type="checkbox"
                          checked={act.completed}
                          onChange={e => handleToggleCompleted(act.id, e.target.checked)}
                          className="h-5 w-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                        />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <MoodSelector activityId={act.id} currentMood={act.mood} onSelect={handleMoodSelect} />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                        <button onClick={() => handleOpenEditModal(act)} className="text-blue-600 hover:text-blue-800 p-1 rounded-full hover:bg-blue-100 transition-colors">
                          <PencilIcon className="w-5 h-5"/>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {patientActivities.length === 0 && <p className="text-center text-gray-500 py-8">No hay actividades registradas para esta persona.</p>}
            </div>
        </div>
      ) : (
        <CalendarView activities={patientActivities} onEditActivity={handleOpenEditModal} />
      )}

       <AddActivityModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} patientId={selectedPatient.id} />
       <EditActivityModal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} activity={selectedActivity} />
    </div>
  );
};

export default ActivitiesScreen;