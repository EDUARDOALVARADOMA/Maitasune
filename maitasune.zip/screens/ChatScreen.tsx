import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { ChatMessage, ChatMemory } from '../types';
import { sendMessageToAI } from '../services/geminiService';
import { useAppContext } from '../context/AppContext';
import { SendIcon, MicrophoneIcon, SpeakerIcon, BookmarkIcon } from '../components/Icons';

// FIX: Add declaration for the non-standard webkitSpeechRecognition API to fix 'Cannot find name' error.
declare global {
  interface Window {
    webkitSpeechRecognition: any;
  }
}

const ChatScreen: React.FC = () => {
  const { selectedPatient, medications, activities, chatMemories, addChatMemory, deleteChatMemory, settings } = useAppContext();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'initial',
      text: 'Hola, soy Maitasune. Estoy aquí para ayudarte con cualquier pregunta o preocupación que tengas sobre el cuidado. ¿Cómo puedo ayudarte hoy?',
      sender: 'ai',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  // FIX: Use `ReturnType<typeof setTimeout>` instead of `NodeJS.Timeout` for browser compatibility.
  const autoPlayTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);


  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Effect to load speech synthesis voices
  useEffect(() => {
    const loadVoices = () => {
      setVoices(speechSynthesis.getVoices());
    };
    speechSynthesis.onvoiceschanged = loadVoices;
    loadVoices(); // Initial load
    return () => {
      speechSynthesis.onvoiceschanged = null;
    };
  }, []);
  
  useEffect(() => {
    if (!('webkitSpeechRecognition' in window)) {
      console.log('Speech recognition not supported');
      return;
    }

    const recognition = new window.webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'es-ES';
    recognition.interimResults = false;

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
    };
    
    recognition.onend = () => {
        setIsListening(false);
    };

    recognitionRef.current = recognition;
  }, []);

  useEffect(() => {
    return () => {
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }
        if (autoPlayTimerRef.current) {
            clearTimeout(autoPlayTimerRef.current);
        }
    };
  }, []);

  const handleSpeak = useCallback((message: ChatMessage) => {
    if (autoPlayTimerRef.current) {
        clearTimeout(autoPlayTimerRef.current);
    }

    if (currentlySpeakingId === message.id) {
        speechSynthesis.cancel();
        setCurrentlySpeakingId(null);
    } else {
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }
        const utterance = new SpeechSynthesisUtterance(message.text);
        
        const availableVoices = voices;
        let selectedVoice: SpeechSynthesisVoice | null = null;
        
        // 1. Try to find the voice selected in settings
        if (settings?.selectedVoiceURI && availableVoices.length > 0) {
            selectedVoice = availableVoices.find(v => v.voiceURI === settings.selectedVoiceURI) || null;
        }
        
        // 2. If no voice is selected in settings or it's not found, use the default logic
        if (!selectedVoice && availableVoices.length > 0) {
            const spanishVoices = availableVoices.filter(v => v.lang.startsWith('es-'));
            const priorityNames = ['Paulina', 'Elena', 'Monica'];
            selectedVoice = spanishVoices.find(v => priorityNames.some(p => v.name.includes(p))) || null;
            
            if (!selectedVoice) {
              selectedVoice = spanishVoices.find(v => v.name.includes('Female') || v.name.includes('Mujer')) || null;
            }

            if (!selectedVoice && spanishVoices.length > 0) {
                selectedVoice = spanishVoices[0];
            }
        }

        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }

        utterance.lang = 'es-ES';
        utterance.rate = settings?.speechRate || 1;
        utterance.pitch = 1; 

        utterance.onend = () => setCurrentlySpeakingId(null);
        utterance.onerror = () => setCurrentlySpeakingId(null); // Ensure state is cleared on error too
        setCurrentlySpeakingId(message.id);
        speechSynthesis.speak(utterance);
    }
  }, [settings, currentlySpeakingId, voices]);
  
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    
    if (lastMessage && lastMessage.sender === 'ai' && lastMessage.id !== 'initial') {
        if (autoPlayTimerRef.current) {
            clearTimeout(autoPlayTimerRef.current);
        }
        
        autoPlayTimerRef.current = setTimeout(() => {
            handleSpeak(lastMessage);
        }, 5000);
    }
  }, [messages, handleSpeak]);

  const handleListen = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };
  
  const handleToggleMemory = (message: ChatMessage) => {
    if (!selectedPatient) return;
    const existingMemory = chatMemories.find(m => m.patientId === selectedPatient.id && m.text === message.text);
    if (existingMemory) {
        deleteChatMemory(existingMemory.id);
    } else {
        addChatMemory({
            patientId: selectedPatient.id,
            text: message.text,
            timestamp: new Date().toISOString()
        });
    }
  };

  const handleSend = async () => {
    if (input.trim() === '' || isLoading) return;

    if (autoPlayTimerRef.current) {
        clearTimeout(autoPlayTimerRef.current);
    }
    if (speechSynthesis.speaking) {
        speechSynthesis.cancel();
        setCurrentlySpeakingId(null);
    }

    const userMessage: ChatMessage = { id: Date.now().toString(), text: input, sender: 'user', timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsLoading(true);
    const patientMemories = selectedPatient ? chatMemories.filter(m => m.patientId === selectedPatient.id) : [];
    
    try {
      const aiResponseText = await sendMessageToAI(currentInput, selectedPatient, medications, activities, patientMemories);
      const aiMessage: ChatMessage = { id: (Date.now() + 1).toString(), text: aiResponseText, sender: 'ai', timestamp: new Date().toISOString() };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: ChatMessage = { id: (Date.now() + 1).toString(), text: 'Lo siento, ocurrió un error. Por favor, inténtalo de nuevo.', sender: 'ai', timestamp: new Date().toISOString() };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-xl shadow-md">
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map(message => {
            const isSaved = message.sender === 'ai' && selectedPatient && chatMemories.some(m => m.patientId === selectedPatient.id && m.text === message.text);
            const isSpeaking = currentlySpeakingId === message.id;

            return (
                <div key={message.id} className={`flex items-end gap-2.5 group ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    {message.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold flex-shrink-0">M</div>}
                    <div className={`relative max-w-xs md:max-w-md lg:max-w-2xl rounded-2xl px-4 py-3 transition-all duration-300 ${message.sender === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-gray-100 text-gray-800 rounded-bl-none'} ${isSpeaking ? 'ring-2 ring-offset-2 ring-blue-400 animate-pulse' : ''}`}>
                        <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{message.text}</p>
                    </div>
                    {message.sender === 'ai' && (
                        <div className="self-center flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button onClick={() => handleSpeak(message)} title={isSpeaking ? "Detener" : "Leer en voz alta"} className={`p-1 rounded-full ${isSpeaking ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}>
                                <SpeakerIcon className="w-5 h-5"/>
                            </button>
                            <button onClick={() => handleToggleMemory(message)} title={isSaved ? "Quitar de la memoria" : "Guardar en la memoria"} className={`p-1 rounded-full ${isSaved ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}>
                                <BookmarkIcon className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
                            </button>
                        </div>
                    )}
                </div>
            );
        })}
        {isLoading && (
          <div className="flex items-end gap-3 justify-start">
             <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold flex-shrink-0">M</div>
            <div className="bg-gray-100 rounded-2xl rounded-bl-none px-4 py-3">
              <div className="flex items-center space-x-1">
                  <span className="h-2 w-2 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="h-2 w-2 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="h-2 w-2 bg-blue-600 rounded-full animate-bounce"></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder={isListening ? "Escuchando..." : "Escribe tu pregunta aquí..."}
            className="w-full pl-12 pr-12 py-3 bg-gray-100 border-2 border-transparent rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
            disabled={isLoading}
          />
          <button
            onClick={handleListen}
            disabled={isLoading}
            title="Dictar por voz"
            className={`absolute left-2.5 top-1/2 -translate-y-1/2 p-2.5 rounded-full hover:bg-gray-200 transition-colors ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-600'}`}
          >
            <MicrophoneIcon />
          </button>
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:bg-gray-300 transition-colors"
          >
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatScreen;