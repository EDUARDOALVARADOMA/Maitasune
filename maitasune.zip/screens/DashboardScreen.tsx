import React from 'react';
import { useAppContext } from '../context/AppContext';
import { PillIcon, ActivityIcon } from '../components/Icons';

const DashboardScreen: React.FC = () => {
  const { selectedPatient, medications, activities, updateMedication, updateActivity } = useAppContext();

  if (!selectedPatient) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-gray-700">Bienvenido a Maitasune</h2>
            <p className="mt-2 text-gray-500">Por favor, seleccione o añada una persona en Ajustes para empezar.</p>
        </div>
      </div>
    );
  }

  const patientMeds = medications
    .filter(med => med.patientId === selectedPatient.id && !med.taken)
    .sort((a, b) => a.time.localeCompare(b.time));
    
  const patientActivities = activities
    .filter(act => act.patientId === selectedPatient.id && !act.completed)
    .sort((a, b) => a.time.localeCompare(b.time));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Medications */}
        <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
          <div className="flex items-center mb-4">
            <div className="p-3 bg-blue-100 rounded-full text-blue-600">
              <PillIcon />
            </div>
            <h2 className="ml-4 text-xl font-semibold text-gray-700">Próximos Medicamentos</h2>
          </div>
          <div className="space-y-3">
            {patientMeds.length > 0 ? (
              patientMeds.slice(0, 3).map(med => (
                <div key={med.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold text-gray-800">{med.name} <span className="text-sm text-gray-500 font-normal">({med.dosage})</span></p>
                    <p className="text-sm text-gray-600">Hora: {med.time}</p>
                  </div>
                  <button onClick={() => updateMedication(med.id, { taken: true })} className="px-3 py-1 text-sm font-medium text-white bg-indigo-600 rounded-full hover:bg-indigo-700 transition">
                    Marcar
                  </button>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 py-4">No hay medicamentos pendientes.</p>
            )}
          </div>
        </div>

        {/* Pending Activities */}
        <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
          <div className="flex items-center mb-4">
            <div className="p-3 bg-green-100 rounded-full text-green-600">
                <ActivityIcon/>
            </div>
            <h2 className="ml-4 text-xl font-semibold text-gray-700">Actividades Pendientes</h2>
          </div>
          <div className="space-y-3">
            {patientActivities.length > 0 ? (
              patientActivities.slice(0, 3).map(act => (
                <div key={act.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold text-gray-800">{act.name}</p>
                    <p className="text-sm text-gray-600">Hora: {act.time}</p>
                  </div>
                  <button onClick={() => updateActivity(act.id, { completed: true })} className="px-3 py-1 text-sm font-medium text-white bg-indigo-600 rounded-full hover:bg-indigo-700 transition">
                    Completar
                  </button>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 py-4">No hay actividades pendientes.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardScreen;