import React, { useState } from 'react';
import { MaitasuneIcon, EyeIcon, EyeOffIcon } from '../components/Icons';
import ForgotPasswordModal from '../components/ForgotPasswordModal';

interface LoginScreenProps {
  onLogin: (email: string, pass: string) => Promise<boolean>;
  onNavigateToRegister: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onNavigateToRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isForgotPasswordModalOpen, setIsForgotPasswordModalOpen] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    const success = await onLogin(email, password);
    if (!success) {
      setError('Correo o contraseña incorrectos.');
    }
    setIsLoading(false);
  };

  return (
    <>
      <div className="flex items-center justify-center min-h-screen bg-gray-200 p-4 font-sans">
        <div className="relative w-full max-w-[390px] h-[844px] bg-white rounded-[50px] shadow-2xl overflow-hidden border-4 border-black flex flex-col">
          
          <div 
            className="absolute w-[150%] h-80 bg-[#4FD1C5] rounded-b-full"
            style={{ top: '-100px', left: '-25%' }}
          ></div>
          
          <div className="absolute bottom-0 left-0 w-full h-80">
            <svg width="100%" height="100%" viewBox="0 0 390 320" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 320V170C130 270, 260 50, 390 170V320H0Z" fill="#3B82F6"/>
            </svg>
          </div>

          <div className="relative z-10 flex flex-col h-full justify-center text-center p-8">
              <div className="absolute top-24 left-1/2 -translate-x-1/2 w-full px-8">
                <h1 className="text-4xl font-extrabold text-black">Bienvenido/a</h1>
                <h1 className="text-4xl font-extrabold text-blue-600">a Maitasune.</h1>
              </div>

              <div className="w-full max-w-sm mx-auto space-y-4">
                <MaitasuneIcon className="w-20 h-auto text-[#4FD1C5] filter drop-shadow-md mx-auto mb-6" />
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <input
                    type="email"
                    placeholder="Correo electrónico"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 text-gray-700 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Contraseña"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 pr-12 text-gray-700 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 flex items-center pr-4 text-gray-600"
                      aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                    >
                      {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                    </button>
                  </div>
                  {error && <p className="text-red-500 text-sm">{error}</p>}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full px-8 py-3 font-bold text-white bg-[#4F46E5] rounded-full focus:outline-none transition-transform transform hover:scale-105 duration-300 shadow-lg disabled:bg-indigo-400 disabled:cursor-not-allowed"
                  >
                    {isLoading ? 'Entrando...' : 'Entrar'}
                  </button>
                </form>
                
                <div className="mt-4 text-center space-y-2">
                   <p className="text-sm text-gray-700">
                    <button onClick={() => setIsForgotPasswordModalOpen(true)} className="font-semibold text-gray-600 hover:underline">
                      ¿Olvidaste tu contraseña?
                    </button>
                  </p>
                  <p className="text-sm text-gray-700">
                    ¿No tienes una cuenta?{' '}
                    <button onClick={onNavigateToRegister} className="font-semibold text-blue-600 hover:underline">
                      Crear una cuenta
                    </button>
                  </p>
                </div>
              </div>
          </div>
        </div>
      </div>
      <ForgotPasswordModal isOpen={isForgotPasswordModalOpen} onClose={() => setIsForgotPasswordModalOpen(false)} />
    </>
  );
};

export default LoginScreen;