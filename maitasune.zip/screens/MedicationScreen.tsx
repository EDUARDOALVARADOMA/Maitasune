import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { PlusIcon, PencilIcon } from '../components/Icons';
import AddMedicationModal from '../components/AddMedicationModal';
import EditMedicationModal from '../components/EditMedicationModal';
import { Medication } from '../types';
import { playCompletionSound } from '../utils/soundUtils';

const MedicationScreen: React.FC = () => {
  const { selectedPatient, medications, updateMedication } = useAppContext();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedMed, setSelectedMed] = useState<Medication | null>(null);

  const handleOpenEditModal = (med: Medication) => {
    setSelectedMed(med);
    setIsEditModalOpen(true);
  };

  const handleToggleTaken = (medicationId: string, isTaken: boolean) => {
    updateMedication(medicationId, { taken: isTaken });
    if (isTaken) {
      playCompletionSound();
    }
  };

  if (!selectedPatient) {
    return (
      <div className="flex items-center justify-center h-full">
         <div className="text-center p-8 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-gray-700">Gestión de Medicación</h2>
            <p className="mt-2 text-gray-500">Seleccione una persona en Ajustes para ver su plan de medicación.</p>
        </div>
      </div>
    );
  }

  const patientMeds = medications.filter(med => med.patientId === selectedPatient.id).sort((a,b) => a.time.localeCompare(b.time));
  const pendingToday = patientMeds.filter(med => !med.taken);
  
  const adherence = patientMeds.length > 0
    ? (patientMeds.filter(m => m.taken).length / patientMeds.length) * 100
    : 0;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-700 mb-2">Tasa de Cumplimiento (Historial)</h3>
        <div className="bg-white p-4 rounded-xl shadow-md">
            <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">Basado en todo el historial registrado</span>
                <span className="text-lg font-bold text-indigo-600">{adherence.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${adherence}%` }}></div>
            </div>
        </div>
      </div>

      <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Medicamentos Pendientes para Hoy</h3>
          <div className="bg-white p-4 rounded-xl shadow-md space-y-3">
            {pendingToday.length > 0 ? (
              pendingToday.map(med => (
                <div key={med.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold text-gray-800">{med.name} <span className="text-sm text-gray-500 font-normal">({med.dosage})</span></p>
                    <p className="text-sm text-gray-600">Hora: {med.time}</p>
                  </div>
                  <button onClick={() => handleToggleTaken(med.id, true)} className="px-3 py-1 text-sm font-medium text-white bg-indigo-600 rounded-full hover:bg-indigo-700 transition">
                    Marcar
                  </button>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 py-4">¡Todo en orden! No hay medicamentos pendientes.</p>
            )}
          </div>
      </div>

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-700">Historial Completo</h3>
        <button 
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition-colors"
        >
            <PlusIcon />
            Añadir
        </button>
      </div>

      <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hora
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Medicamento
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dosis
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Estado
                </th>
                 <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Editar
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {patientMeds.map(med => (
                <tr key={med.id} className={med.taken ? 'bg-green-50' : ''}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{med.time}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{med.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{med.dosage}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    <input
                      type="checkbox"
                      checked={med.taken}
                      onChange={e => handleToggleTaken(med.id, e.target.checked)}
                      className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">
                    <button onClick={() => handleOpenEditModal(med)} className="text-indigo-600 hover:text-indigo-800 p-1 rounded-full hover:bg-indigo-100 transition-colors">
                      <PencilIcon className="w-5 h-5"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {patientMeds.length === 0 && <p className="text-center text-gray-500 py-8">No hay medicamentos registrados para esta persona.</p>}
        </div>
      </div>
      <AddMedicationModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} patientId={selectedPatient.id} />
      <EditMedicationModal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} medication={selectedMed} />
    </div>
  );
};

export default MedicationScreen;