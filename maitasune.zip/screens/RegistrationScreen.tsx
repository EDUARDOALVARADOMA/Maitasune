

import React, { useState } from 'react';
import { MaitasuneIcon, EyeIcon, EyeOffIcon } from '../components/Icons';
import type { User } from '../types';

interface RegistrationScreenProps {
  onRegister: (userData: Omit<User, 'id'>) => Promise<boolean>;
  onNavigateToLogin: () => void;
}

const RegistrationScreen: React.FC<RegistrationScreenProps> = ({ onRegister, onNavigateToLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [role, setRole] = useState<'caregiver' | 'family' | 'company'>('family');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    setError('');
    setIsLoading(true);
    const success = await onRegister({ name, email, password, role });
    if (!success) {
      setError('Este correo electrónico ya está en uso.');
    }
    setIsLoading(false);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-200 p-4 font-sans">
      <div className="relative w-full max-w-[390px] h-[844px] bg-white rounded-[50px] shadow-2xl overflow-hidden border-4 border-black flex flex-col">
        
        <div 
          className="absolute w-[150%] h-80 bg-[#4FD1C5] rounded-b-full"
          style={{ top: '-100px', left: '-25%' }}
        ></div>
        
        <div className="absolute bottom-0 left-0 w-full h-80">
          <svg width="100%" height="100%" viewBox="0 0 390 320" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 320V170C130 270, 260 50, 390 170V320H0Z" fill="#3B82F6"/>
          </svg>
        </div>

        <div className="relative z-10 flex flex-col h-full justify-center text-center p-8">
            <div className="absolute top-24 left-1/2 -translate-x-1/2 w-full px-8">
              <h1 className="text-4xl font-extrabold text-black">Crea tu cuenta</h1>
              <h1 className="text-4xl font-extrabold text-blue-600">en Maitasune.</h1>
            </div>

            <div className="w-full max-w-sm mx-auto space-y-4 mt-20">
              <MaitasuneIcon className="w-16 h-auto text-[#4FD1C5] filter drop-shadow-md mx-auto mb-4" />
              
              <form onSubmit={handleSubmit} className="space-y-3">
                <input
                  type="text"
                  placeholder="Nombre completo"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 text-gray-700 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                 <input
                  type="email"
                  placeholder="Correo electrónico"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 text-gray-700 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Contraseña (mín. 6 caracteres)"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 pr-12 text-gray-700 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                    <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 flex items-center pr-4 text-gray-600"
                        aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                    >
                        {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                    </button>
                </div>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as User['role'])}
                  className="w-full px-4 py-3 text-gray-700 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none text-center"
                >
                  <option value="family">Soy un Familiar</option>
                  <option value="caregiver">Soy Cuidador Profesional</option>
                  <option value="company">Soy una Empresa</option>
                </select>

                {error && <p className="text-red-500 text-xs pt-1">{error}</p>}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full px-8 py-3 font-bold text-white bg-[#4F46E5] rounded-full focus:outline-none transition-transform transform hover:scale-105 duration-300 shadow-lg disabled:bg-indigo-400 disabled:cursor-not-allowed mt-2"
                >
                  {isLoading ? 'Creando cuenta...' : 'Registrar'}
                </button>
              </form>
              
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-700">
                  ¿Ya tienes una cuenta?{' '}
                  <button onClick={onNavigateToLogin} className="font-semibold text-blue-600 hover:underline">
                    Iniciar sesión
                  </button>
                </p>
              </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default RegistrationScreen;