import React from 'react';
import { useAppContext } from '../context/AppContext';
import { Activity, Medication } from '../types';

const ReportsScreen: React.FC = () => {
  const { selectedPatient, medications, activities } = useAppContext();

  if (!selectedPatient) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center p-8 bg-white rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-gray-700">Informes y Seguimiento</h2>
            <p className="mt-2 text-gray-500">Seleccione una persona en Ajustes para ver su resumen.</p>
        </div>
      </div>
    );
  }

  // NOTE: A true weekly report would require date tracking for each record.
  // This simulation uses all available data to represent "recent activity".
  
  // --- Data for historical adherence rates ---
  const patientMeds: Medication[] = medications.filter(med => med.patientId === selectedPatient.id);
  const patientActivities: Activity[] = activities.filter(act => act.patientId === selectedPatient.id);

  const medicationAdherence = patientMeds.length > 0
    ? (patientMeds.filter(m => m.taken).length / patientMeds.length) * 100
    : 0;

  const activityCompletion = patientActivities.length > 0
    ? (patientActivities.filter(a => a.completed).length / patientActivities.length) * 100
    : 0;
    
  // --- Data for weekly summary & mood chart ---
  // We assume the current data represents the last week.
  const medsTakenThisWeek = patientMeds.filter(m => m.taken).length;
  const activitiesCompletedThisWeek = patientActivities.filter(a => a.completed).length;

  const moodCounts = patientActivities
    .filter(a => a.completed && a.mood)
    .reduce((acc, activity) => {
        if (activity.mood) {
            acc[activity.mood] = (acc[activity.mood] || 0) + 1;
        }
        return acc;
    }, { happy: 0, neutral: 0, sad: 0 } as Record<'happy' | 'neutral' | 'sad', number>);
  

  // --- Reusable Components ---
  const StatCard: React.FC<{title: string; value: string; subtext: string;}> = ({ title, value, subtext }) => (
      <div className="bg-white p-6 rounded-xl shadow-md flex flex-col items-center justify-center text-center">
          <h3 className="text-lg font-semibold text-gray-500">{title}</h3>
          <p className="text-4xl font-bold text-blue-600 my-2">{value}</p>
          <p className="text-sm text-gray-400">{subtext}</p>
      </div>
  );

  const MoodBarChart: React.FC<{data: Record<'happy' | 'neutral' | 'sad', number>}> = ({ data }) => {
    const total = Object.values(data).reduce((sum, count) => sum + count, 0);
    const emojiMap = { happy: '😊', neutral: '😐', sad: '😔' };
    const colorMap = { happy: 'bg-green-500', neutral: 'bg-gray-400', sad: 'bg-red-500' };
    
    const barData = (Object.keys(data) as Array<keyof typeof data>).map(mood => ({
        mood,
        count: data[mood],
        color: colorMap[mood],
        emoji: emojiMap[mood],
    }));

    if (total === 0) {
        return <p className="text-center text-gray-500 py-4">No se ha registrado el estado de ánimo en ninguna actividad completada.</p>;
    }
    
    return (
        <div className="flex justify-around items-end h-40 pt-4 gap-4">
            {barData.map(item => (
                <div key={item.mood} className="flex flex-col items-center flex-1">
                    <span className="text-sm font-semibold text-gray-700">{item.count}</span>
                    <div 
                        className={`w-full max-w-[50px] rounded-t-lg ${item.color} transition-all duration-500`}
                        style={{ height: `${(item.count / total) * 100}%` }}
                        title={`${item.count} ${item.mood}`}
                    />
                    <span className="text-3xl mt-2">{item.emoji}</span>
                </div>
            ))}
        </div>
    );
  };


  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Resumen Semanal</h2>
        <p className="text-sm text-gray-500 mb-4 -mt-3">
          (Nota: Simulación basada en todos los datos disponibles)
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg text-center">
                <h3 className="font-semibold text-blue-800">Medicamentos Tomados</h3>
                <p className="text-3xl font-bold text-blue-700">{medsTakenThisWeek}</p>
            </div>
             <div className="bg-green-50 p-4 rounded-lg text-center">
                <h3 className="font-semibold text-green-800">Actividades Completadas</h3>
                <p className="text-3xl font-bold text-green-700">{activitiesCompletedThisWeek}</p>
            </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-md">
        <h2 className="text-xl font-semibold text-gray-700 mb-2">Distribución de Ánimo (Semanal)</h2>
        <MoodBarChart data={moodCounts} />
      </div>
      
      <div>
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Tasas de Cumplimiento (Historial)</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <StatCard title="Adherencia a Medicación" value={`${medicationAdherence.toFixed(0)}%`} subtext="del total de dosis registradas" />
            <StatCard title="Finalización de Actividades" value={`${activityCompletion.toFixed(0)}%`} subtext="del total de actividades registradas" />
        </div>
      </div>

    </div>
  );
};

export default ReportsScreen;