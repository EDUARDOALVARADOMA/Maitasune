import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import { BellIcon, BellOffIcon, LogOutIcon, PlusIcon, PencilIcon, UsersIcon, SpeakerIcon, FastForwardIcon, TrashIcon, UserCircleIcon } from '../components/Icons';
import AddPatientModal from '../components/AddPatientModal';
import EditPatientModal from '../components/EditPatientModal';
import { Patient } from '../types';

interface SettingsScreenProps {
  onLogout: () => void;
}

// A list of names to assign to voices that don't have a clear human name.
const voiceNames = [
    "Andres", "Valentina", "Isabella", "Camila", "Valeria", "Mariana", "Gabriela", "Daniela", "Paula", "Victoria",
    "Martina", "Lucía", "Ximena", "Sara", "Samantha", "María José", "Emma", "Juana", "Renata", "Abril"
];

// Helper to get a consistent name from the list based on the voice's URI
const getConsistentName = (voiceURI: string, index: number): string => {
    // Some URIs might be very simple, so index provides extra stability
    let hash = 0;
    for (let i = 0; i < voiceURI.length; i++) {
        const char = voiceURI.charCodeAt(i);
        hash = (hash << 5) - hash + char;
        hash |= 0; // Convert to 32bit integer
    }
    return voiceNames[(Math.abs(hash) + index) % voiceNames.length];
};

// Helper to get a user-friendly region name from the language code.
const getRegionName = (lang: string): string => {
    try {
        const regionCode = lang.split('-')[1];
        if (!regionCode) return lang;
        // Use Intl.DisplayNames for accurate, localized region names.
        const regionName = new Intl.DisplayNames(['es'], { type: 'region' }).of(regionCode.toUpperCase());
        return regionName || regionCode;
    } catch (e) {
        // Fallback for older browsers or unexpected language codes.
        return lang.split('-')[1] || lang;
    }
};


const SettingsScreen: React.FC<SettingsScreenProps> = ({ onLogout }) => {
    const { currentUser, settings, updateSettings, patients, selectedPatient, setSelectedPatient, deletePatient } = useAppContext();
    const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
    const [isEditPatientModalOpen, setIsEditPatientModalOpen] = useState(false);
    const [patientToEdit, setPatientToEdit] = useState<Patient | null>(null);
    const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

    useEffect(() => {
        const loadVoices = () => {
            const availableVoices = speechSynthesis.getVoices();
            setVoices(availableVoices);
        };
        // Voices are loaded asynchronously. The 'voiceschanged' event fires when they are ready.
        speechSynthesis.onvoiceschanged = loadVoices;
        // Also call it directly in case they are already loaded.
        loadVoices();
        
        return () => {
            speechSynthesis.onvoiceschanged = null;
        };
    }, []);

    const spanishVoices = voices.filter(v => v.lang.startsWith('es-'));

    // Updated function to provide friendly, distinct names for each voice option.
    const formatVoiceName = (voice: SpeechSynthesisVoice, index: number): string => {
        const name = voice.name.toLowerCase();
        const region = getRegionName(voice.lang);

        // Prioritize well-known, high-quality voice names.
        if (name.includes('sabina')) return `Sabina (${region})`;
        if (name.includes('paulina')) return `Paulina (${region})`;
        if (name.includes('monica') || name.includes('mónica')) return `Mónica (${region})`;
        if (name.includes('elena')) return `Elena (${region})`;

        // For generic voices (like Google's), assign a consistent name from our list.
        const assignedName = getConsistentName(voice.voiceURI, index);
        return `${assignedName} (${region})`;
    };


    const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedVoiceURI = e.target.value;
        updateSettings({ selectedVoiceURI });
    
        // Cancel any currently playing speech
        if (speechSynthesis.speaking) {
            speechSynthesis.cancel();
        }
    
        // If a voice is selected (not the "default" option), play a sample
        if (selectedVoiceURI) {
            const selectedVoice = spanishVoices.find(v => v.voiceURI === selectedVoiceURI);
            if (selectedVoice) {
                const utterance = new SpeechSynthesisUtterance('Hola, así es como sueno.');
                utterance.voice = selectedVoice;
                utterance.lang = selectedVoice.lang;
                utterance.rate = settings?.speechRate || 1;
                speechSynthesis.speak(utterance);
            }
        }
    };

    const handleNotificationToggle = async () => {
        const isEnabled = settings?.notificationsEnabled;

        if (!isEnabled) { 
            if (!('Notification' in window)) {
                alert('Este navegador no soporta notificaciones de escritorio.');
                return;
            }

            if (Notification.permission === 'default') {
                const permission = await Notification.requestPermission();
                if (permission === 'granted') {
                    await updateSettings({ notificationsEnabled: true });
                    new Notification('¡Notificaciones Activadas!', {
                        body: 'Maitasune ahora te enviará recordatorios de medicación.',
                        icon: '/logo.png',
                    });
                }
            } else if (Notification.permission === 'granted') {
                await updateSettings({ notificationsEnabled: true });
            } else {
                alert('Las notificaciones están bloqueadas. Por favor, habilítalas en la configuración de tu navegador para usar esta función.');
            }
        } else { 
            await updateSettings({ notificationsEnabled: false });
        }
    };

    const handleDeletePatient = (patient: Patient) => {
        if (window.confirm(`¿Estás seguro de que quieres eliminar a ${patient.name}? Esta acción es irreversible y borrará todos sus datos asociados (medicamentos, actividades, etc.).`)) {
            deletePatient(patient.id);
        }
    };

    const handleEditPatient = (patient: Patient) => {
        setPatientToEdit(patient);
        setIsEditPatientModalOpen(true);
    };
    
    // Capitalize first letter of a string
    const capitalize = (s: string | undefined) => s && s.charAt(0).toUpperCase() + s.slice(1);

    return (
        <div className="space-y-6">
            {currentUser && (
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <h2 className="text-xl font-semibold text-gray-700 mb-4 flex items-center gap-2"><UserCircleIcon /> Perfil del Cuidador</h2>
                    <div className="space-y-1 text-gray-600">
                        <p><span className="font-semibold text-gray-800">Nombre:</span> {currentUser.name}</p>
                        <p><span className="font-semibold text-gray-800">Correo:</span> {currentUser.email}</p>
                        <p><span className="font-semibold text-gray-800">Rol:</span> {capitalize(currentUser.role)}</p>
                    </div>
                </div>
            )}

            <div className="bg-white p-6 rounded-xl shadow-md">
                <h2 className="text-xl font-semibold text-gray-700 mb-4 flex items-center gap-2"><UsersIcon /> Gestión de Personas</h2>
                
                <div className="space-y-2">
                    {patients.map(p => (
                        <div key={p.id} 
                            onClick={() => setSelectedPatient(p)}
                            className={`group flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${selectedPatient?.id === p.id ? 'bg-blue-100 ring-2 ring-blue-300' : 'hover:bg-gray-100'}`}
                        >
                            <div className="flex items-center gap-3">
                                <img src={p.avatarUrl} alt={p.name} className="w-10 h-10 rounded-full object-cover" />
                                <span className="font-medium text-gray-800">{p.name}</span>
                            </div>
                            <div className="flex items-center gap-1 opacity-0 transform translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
                                <button onClick={(e) => { e.stopPropagation(); handleEditPatient(p); }} className="text-blue-600 p-1 rounded-full hover:bg-blue-200" aria-label={`Editar ${p.name}`}>
                                    <PencilIcon className="w-5 h-5"/>
                                </button>
                                <button onClick={(e) => { e.stopPropagation(); handleDeletePatient(p); }} className="text-red-600 p-1 rounded-full hover:bg-red-100" aria-label={`Eliminar ${p.name}`}>
                                    <TrashIcon className="w-5 h-5"/>
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
                
                <button
                    onClick={() => setIsAddPatientModalOpen(true)}
                    className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-gray-300 text-gray-600 font-semibold rounded-lg hover:bg-gray-100 hover:border-gray-400 transition-colors"
                >
                    <PlusIcon />
                    Añadir Persona
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <h2 className="text-xl font-semibold text-gray-700 mb-4">Preferencias</h2>
                
                <div className="flex items-center justify-between py-4 border-b">
                    <div className="flex items-center">
                        {settings?.notificationsEnabled ? <BellIcon className="w-6 h-6 text-blue-600" /> : <BellOffIcon className="w-6 h-6 text-gray-500" />}
                        <span className="ml-4 font-medium text-gray-700">Recordatorios</span>
                    </div>
                    <label htmlFor="notification-toggle" className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        id="notification-toggle" 
                        className="sr-only peer"
                        checked={settings?.notificationsEnabled || false}
                        onChange={handleNotificationToggle}
                      />
                      <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>

                <div className="flex items-center justify-between py-4 border-b">
                    <div className="flex items-center">
                        <SpeakerIcon className="w-6 h-6 text-blue-600" />
                        <span className="ml-4 font-medium text-gray-700">Voz del Asistente</span>
                    </div>
                    <select
                        id="voice-select"
                        value={settings?.selectedVoiceURI || ''}
                        onChange={handleVoiceChange}
                        disabled={spanishVoices.length === 0}
                        className="block w-1/2 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md disabled:bg-gray-100"
                    >
                        <option value="">Maitasune (Defecto)</option>
                        {spanishVoices.map((voice, index) => (
                            <option key={voice.voiceURI} value={voice.voiceURI}>
                                {formatVoiceName(voice, index)}
                            </option>
                        ))}
                    </select>
                </div>
                
                <div className="flex flex-col gap-2 py-4">
                    <div className="flex items-center justify-between">
                         <div className="flex items-center">
                             <FastForwardIcon className="w-6 h-6 text-blue-600" />
                             <span className="ml-4 font-medium text-gray-700">Velocidad de Lectura</span>
                         </div>
                         <span className="font-semibold text-blue-700 w-12 text-center">{`${(settings?.speechRate || 1).toFixed(1)}x`}</span>
                    </div>
                     <input
                         type="range"
                         min="0.5"
                         max="2"
                         step="0.1"
                         value={settings?.speechRate || 1}
                         onChange={(e) => updateSettings({ speechRate: parseFloat(e.target.value) })}
                         className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                     />
                 </div>

                <div className="mt-8">
                    <button
                        onClick={onLogout}
                        className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-50 text-red-600 font-bold rounded-lg hover:bg-red-100 transition-colors"
                    >
                        <LogOutIcon />
                        Cerrar Sesión
                    </button>
                </div>
            </div>
            
            <AddPatientModal isOpen={isAddPatientModalOpen} onClose={() => setIsAddPatientModalOpen(false)} />
            <EditPatientModal 
                isOpen={isEditPatientModalOpen} 
                onClose={() => {
                    setIsEditPatientModalOpen(false);
                    setPatientToEdit(null);
                }} 
                patient={patientToEdit}
             />
        </div>
    );
};

export default SettingsScreen;