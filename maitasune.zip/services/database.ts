import { INITIAL_USERS, INITIAL_USER_SETTINGS, INITIAL_PATIENTS, INITIAL_MEDICATIONS, INITIAL_ACTIVITIES } from '../constants';
import type { User, UserSettings, Patient, Medication, Activity, ChatMemory } from '../types';

/**
 * NOTE: This is a mock API service that uses localStorage to simulate a backend database.
 * It's designed to be easily replaceable with actual HTTP requests (e.g., using fetch)
 * to a real backend server once it's developed.
 * A simulated latency is added to mimic real-world network conditions.
 */
const API_LATENCY = 250; // ms

// --- LocalStorage Keys ---
const USERS_KEY = 'maitasune_users';
const SETTINGS_KEY = 'maitasune_userSettings';
const PATIENTS_KEY = 'maitasune_patients';
const MEDICATIONS_KEY = 'maitasune_medications';
const ACTIVITIES_KEY = 'maitasune_activities';
const MEMORIES_KEY = 'maitasune_chatMemories';

// --- Helper functions for LocalStorage ---
const readFromStorage = <T>(key: string, defaultValue: T): T => {
    try {
        const item = window.localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.warn(`Error reading from localStorage key “${key}”:`, error);
        return defaultValue;
    }
};

const writeToStorage = <T>(key: string, value: T): void => {
    try {
        window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error(`Error writing to localStorage key “${key}”:`, error);
    }
};

// --- Database Initialization ---
// This function seeds the database if it's empty.
const initializeDatabase = () => {
    if (!localStorage.getItem(USERS_KEY)) {
        writeToStorage(USERS_KEY, INITIAL_USERS);
        writeToStorage(SETTINGS_KEY, INITIAL_USER_SETTINGS);
        writeToStorage(PATIENTS_KEY, INITIAL_PATIENTS);
        writeToStorage(MEDICATIONS_KEY, INITIAL_MEDICATIONS);
        writeToStorage(ACTIVITIES_KEY, INITIAL_ACTIVITIES);
        writeToStorage(MEMORIES_KEY, []);
    }
};

// Run initialization once
initializeDatabase();

// --- API Service Simulation Wrapper ---
const simulateApiCall = <T>(logic: () => T): Promise<T> => {
    return new Promise(resolve => {
        setTimeout(() => {
            try {
                const result = logic();
                resolve(result);
            } catch (error) {
                console.error("Simulated API Error:", error);
                resolve(undefined as T); 
            }
        }, API_LATENCY);
    });
};


export const api = {
  // --- USER ---
  async getUser(userId: string): Promise<User | undefined> {
    return simulateApiCall(() => {
      const users = readFromStorage<User[]>(USERS_KEY, []);
      return users.find(u => u.id === userId);
    });
  },
  async findUserByEmail(email: string): Promise<User | null> {
    return simulateApiCall(() => {
      const users = readFromStorage<User[]>(USERS_KEY, []);
      const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      // NOTE: In a real app, never return the full user object with password here.
      // This is safe only because it's a mock frontend-only database.
      return user || null;
    });
  },
  async authenticateUser(email: string, password_param: string): Promise<User | null> {
    return simulateApiCall(() => {
      const users = readFromStorage<User[]>(USERS_KEY, []);
      const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (user && user.password === password_param) {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword as User;
      }
      return null;
    });
  },
  async addUser(userData: Omit<User, 'id'>): Promise<User | null> {
    return simulateApiCall(() => {
      const users = readFromStorage<User[]>(USERS_KEY, []);
      const userSettings = readFromStorage<UserSettings[]>(SETTINGS_KEY, []);
      
      const existingUser = users.find(u => u.email.toLowerCase() === userData.email.toLowerCase());
      if (existingUser) {
        return null; // Email already exists
      }
      const newUser: User = { ...userData, id: `user${Date.now()}` };
      const newUserSettings: UserSettings = {
        userId: newUser.id,
        theme: 'light',
        notificationsEnabled: true,
        speechRate: 1,
      };

      writeToStorage(USERS_KEY, [...users, newUser]);
      writeToStorage(SETTINGS_KEY, [...userSettings, newUserSettings]);
      
      const { password, ...userWithoutPassword } = newUser;
      return userWithoutPassword as User;
    });
  },

  // --- SETTINGS ---
  async getSettings(userId: string): Promise<UserSettings | undefined> {
    return simulateApiCall(() => {
      const settings = readFromStorage<UserSettings[]>(SETTINGS_KEY, []);
      return settings.find(s => s.userId === userId);
    });
  },
  async updateSettings(userId: string, updates: Partial<UserSettings>): Promise<UserSettings | undefined> {
    return simulateApiCall(() => {
      const settings = readFromStorage<UserSettings[]>(SETTINGS_KEY, []);
      const index = settings.findIndex(s => s.userId === userId);
      if (index > -1) {
        settings[index] = { ...settings[index], ...updates };
        writeToStorage(SETTINGS_KEY, settings);
        return settings[index];
      }
      return undefined;
    });
  },

  // --- PATIENTS ---
  async getPatients(userId: string): Promise<Patient[]> {
    return simulateApiCall(() => {
      const patients = readFromStorage<Patient[]>(PATIENTS_KEY, []);
      return patients.filter(p => p.userId === userId);
    });
  },
  async addPatient(patientData: Omit<Patient, 'id'>): Promise<Patient> {
    return simulateApiCall(() => {
      const patients = readFromStorage<Patient[]>(PATIENTS_KEY, []);
      const newPatient: Patient = { ...patientData, id: Date.now().toString() };
      writeToStorage(PATIENTS_KEY, [...patients, newPatient]);
      return newPatient;
    });
  },
  async updatePatient(patientId: string, updates: Partial<Patient>): Promise<Patient | undefined> {
    return simulateApiCall(() => {
      const patients = readFromStorage<Patient[]>(PATIENTS_KEY, []);
      const index = patients.findIndex(p => p.id === patientId);
      if (index > -1) {
        patients[index] = { ...patients[index], ...updates };
        writeToStorage(PATIENTS_KEY, patients);
        return patients[index];
      }
      return undefined;
    });
  },
  async deletePatient(patientId: string): Promise<boolean> {
    return simulateApiCall(() => {
      let patients = readFromStorage<Patient[]>(PATIENTS_KEY, []);
      let medications = readFromStorage<Medication[]>(MEDICATIONS_KEY, []);
      let activities = readFromStorage<Activity[]>(ACTIVITIES_KEY, []);
      let chatMemories = readFromStorage<ChatMemory[]>(MEMORIES_KEY, []);
      
      const initialLength = patients.length;
      patients = patients.filter(p => p.id !== patientId);
      
      if (patients.length < initialLength) {
          writeToStorage(PATIENTS_KEY, patients);
          writeToStorage(MEDICATIONS_KEY, medications.filter(m => m.patientId !== patientId));
          writeToStorage(ACTIVITIES_KEY, activities.filter(a => a.patientId !== patientId));
          writeToStorage(MEMORIES_KEY, chatMemories.filter(m => m.patientId !== patientId));
          return true;
      }
      return false;
    });
  },


  // --- MEDICATIONS ---
  async getMedications(): Promise<Medication[]> {
      return simulateApiCall(() => readFromStorage<Medication[]>(MEDICATIONS_KEY, []));
  },
  async addMedication(medData: Omit<Medication, 'id'>): Promise<Medication> {
    return simulateApiCall(() => {
      const medications = readFromStorage<Medication[]>(MEDICATIONS_KEY, []);
      const newMedication: Medication = { ...medData, id: Date.now().toString() };
      writeToStorage(MEDICATIONS_KEY, [...medications, newMedication]);
      return newMedication;
    });
  },
  async updateMedication(medId: string, updates: Partial<Medication>): Promise<Medication | undefined> {
    return simulateApiCall(() => {
      const medications = readFromStorage<Medication[]>(MEDICATIONS_KEY, []);
      const index = medications.findIndex(m => m.id === medId);
      if (index > -1) {
        medications[index] = { ...medications[index], ...updates };
        writeToStorage(MEDICATIONS_KEY, medications);
        return medications[index];
      }
      return undefined;
    });
  },

  // --- ACTIVITIES ---
  async getActivities(): Promise<Activity[]> {
      return simulateApiCall(() => readFromStorage<Activity[]>(ACTIVITIES_KEY, []));
  },
  async addActivity(activityData: Omit<Activity, 'id'>): Promise<Activity> {
    return simulateApiCall(() => {
      const activities = readFromStorage<Activity[]>(ACTIVITIES_KEY, []);
      const newActivity: Activity = { ...activityData, id: Date.now().toString() };
      writeToStorage(ACTIVITIES_KEY, [...activities, newActivity]);
      return newActivity;
    });
  },
  async updateActivity(activityId: string, updates: Partial<Activity>): Promise<Activity | undefined> {
    return simulateApiCall(() => {
      const activities = readFromStorage<Activity[]>(ACTIVITIES_KEY, []);
      const index = activities.findIndex(a => a.id === activityId);
      if (index > -1) {
        activities[index] = { ...activities[index], ...updates };
        writeToStorage(ACTIVITIES_KEY, activities);
        return activities[index];
      }
      return undefined;
    });
  },

  // --- CHAT MEMORY ---
  async getChatMemories(patientId: string): Promise<ChatMemory[]> {
    return simulateApiCall(() => {
      const memories = readFromStorage<ChatMemory[]>(MEMORIES_KEY, []);
      return memories.filter(m => m.patientId === patientId);
    });
  },
  async addChatMemory(memoryData: Omit<ChatMemory, 'id'>): Promise<ChatMemory> {
    return simulateApiCall(() => {
      const memories = readFromStorage<ChatMemory[]>(MEMORIES_KEY, []);
      const existing = memories.find(m => m.patientId === memoryData.patientId && m.text === memoryData.text);
      if (existing) return existing;

      const newMemory: ChatMemory = { ...memoryData, id: Date.now().toString() };
      writeToStorage(MEMORIES_KEY, [...memories, newMemory]);
      return newMemory;
    });
  },
  async deleteChatMemory(memoryId: string): Promise<boolean> {
    return simulateApiCall(() => {
      let memories = readFromStorage<ChatMemory[]>(MEMORIES_KEY, []);
      const initialLength = memories.length;
      memories = memories.filter(m => m.id !== memoryId);
      if (memories.length < initialLength) {
          writeToStorage(MEMORIES_KEY, memories);
          return true;
      }
      return false;
    });
  },
};