import { GoogleGenAI } from "@google/genai";
import type { Patient, Medication, Activity, ChatMemory } from '../types';


const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const model = 'gemini-2.5-flash';

const systemInstruction = `Eres Maitasune, un asistente de IA compasivo y experto en el cuidado de personas. 
Tu propósito es apoyar a los cuidadores (trabajadores sociosanitarios y familiares) ofreciendo consejos prácticos, 
apoyo emocional y sugerencias para el autocuidado. 
Basarás tus respuestas en el contexto proporcionado sobre la persona cuidada y sus tareas pendientes, además de tu conocimiento general.
Responde siempre en un tono amable, empático y profesional en español. 
Evita dar consejos médicos directos y, en su lugar, sugiere consultar a un profesional de la salud. 
Enfócate en el bienestar tanto de la persona cuidada como del cuidador.`;


export const sendMessageToAI = async (message: string, patient: Patient | null, medications: Medication[], activities: Activity[], memories: ChatMemory[]): Promise<string> => {
  let context = "No hay una persona seleccionada para el cuidado en este momento.";
  
  if (patient) {
      const pendingMeds = medications.filter(m => m.patientId === patient.id && !m.taken).map(m => `- ${m.name} (${m.dosage}) a las ${m.time}`).join('\n');
      const pendingActivities = activities.filter(a => a.patientId === patient.id && !a.completed).map(a => `- ${a.name} a las ${a.time}`).join('\n');
      const memoryContext = memories.length > 0
        ? `\nMemoria a Largo Plazo (Sugerencias importantes guardadas por el cuidador):\n${memories.map(m => `  - ${m.text}`).join('\n')}`
        : '';

      context = `
      Contexto actual del cuidado:
      - Persona Cuidada: ${patient.name}, ${patient.age} años.
      - Condición: ${patient.condition}.
      ${memoryContext}
      
      Tareas Pendientes Hoy:
      - Medicamentos por tomar:
      ${pendingMeds || '  - Ninguno.'}
      - Actividades por realizar:
      ${pendingActivities || '  - Ninguna.'}
      `;
  }
    
  const fullPrompt = `${context}\n\nPregunta del cuidador: "${message}"`;

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: fullPrompt,
        config: {
            systemInstruction: systemInstruction,
        }
    });
    
    return response.text;
  } catch (error) {
    console.error("Error communicating with Gemini API:", error);
    return "Lo siento, estoy teniendo problemas para conectarme en este momento. Por favor, inténtalo de nuevo más tarde.";
  }
};