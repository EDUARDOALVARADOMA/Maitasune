

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: 'caregiver' | 'family' | 'company';
}

export interface UserSettings {
  userId: string;
  theme: 'light' | 'dark';
  notificationsEnabled: boolean;
  selectedVoiceURI?: string;
  speechRate?: number;
}

export interface Patient {
  id: string;
  userId: string;
  name: string;
  avatarUrl: string;
  age: number;
  condition: string;
  notes?: string;
}

export interface Medication {
  id: string;
  patientId: string;
  name: string;
  dosage: string;
  time: string;
  taken: boolean;
}

export interface Activity {
  id: string;
  patientId: string;
  name: string;
  date: string; // YYYY-MM-DD format
  time: string;
  completed: boolean;
  mood?: 'happy' | 'neutral' | 'sad';
  reminderOffset?: number; // Minutes before the activity to send a reminder
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

export interface ChatMemory {
  id: string;
  patientId: string;
  text: string;
  timestamp: string;
}