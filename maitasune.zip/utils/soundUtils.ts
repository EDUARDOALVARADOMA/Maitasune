// utils/soundUtils.ts

// Create a single AudioContext to be reused globally to avoid performance issues.
let audioCtx: AudioContext | null = null;

const initializeAudioContext = () => {
  if (!audioCtx) {
    // Check for Safari/old browser compatibility
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContext) {
      audioCtx = new AudioContext();
    } else {
      console.warn("Web Audio API is not supported in this browser.");
    }
  }
};

/**
 * Plays a short, pleasant "click" sound to confirm an action.
 * This is generated programmatically using the Web Audio API to avoid loading external files.
 */
export const playCompletionSound = () => {
  initializeAudioContext();
  if (!audioCtx) return;

  // If the context is suspended (common in modern browsers until user interaction), resume it.
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  const oscillator = audioCtx.createOscillator();
  const gainNode = audioCtx.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(audioCtx.destination);

  // --- Sound Parameters ---
  const now = audioCtx.currentTime;
  gainNode.gain.setValueAtTime(0, now);
  gainNode.gain.linearRampToValueAtTime(0.4, now + 0.01); // Quick attack to avoid "pop"

  oscillator.type = 'sine'; // A clean, simple waveform
  oscillator.frequency.setValueAtTime(988, now); // B5 note - a high, positive pitch

  oscillator.start(now);
  
  // Exponentially decay the sound to make it feel soft
  gainNode.gain.exponentialRampToValueAtTime(0.00001, now + 0.1); 
  oscillator.stop(now + 0.1);
};
